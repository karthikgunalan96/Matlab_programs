a=zeros(40);
b=ones(40);
c=[a b; b a];
d=[b b; a a];
A=10*(c+d);
M=c.*d;
S=c+d;
D=c/4;
u=and(c,d);
v=or(c,d);
w=xor(c,d);
figure;
subplot(3,3,1);
imshow(c);
subplot(3,3,2);
imshow(d);
subplot(3,3,3);
imshow(A);
subplot(3,3,4);
imshow(M);
subplot(3,3,5);
imshow(S);
subplot(3,3,6);
imshow(D);
subplot(3,3,7);
imshow(u);
subplot(3,3,8);
imshow(v);
subplot(3,3,9);
imshow(w);






