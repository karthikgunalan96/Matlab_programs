i=imread('peppers.png');

l=i+1;
imshow(l);
