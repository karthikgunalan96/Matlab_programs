clc;
a=magic(5);

disp(a);
b=input('rows less than size of matrix');
c=input('columns less than size of matrix');
n4=[a(b-1,c);a(b+1,c);a(b,c-1);a(b,c+1)];
disp(n4);

