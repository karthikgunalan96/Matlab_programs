i=imread('peppers.png');
figure;
subplot(2,2,1);
imshow(i);
c=imcomplement(i);
subplot(2,2,2);
imshow(c);
w=rgb2gray(c);
subplot(2,2,3);
imshow(w);
d=imcomplement(w);
subplot(2,2,4);
imshow(d);

